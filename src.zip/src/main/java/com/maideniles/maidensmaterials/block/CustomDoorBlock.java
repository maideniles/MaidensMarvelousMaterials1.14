package com.maideniles.maidensmaterials.block;

import net.minecraft.block.DoorBlock;

public class CustomDoorBlock extends DoorBlock {
    public CustomDoorBlock(Properties builder) {
        super(builder);
    }
}
