package com.maideniles.maidensmaterials.block;

import net.minecraft.block.PressurePlateBlock;

public class CustomPressurePlate extends PressurePlateBlock {
    public CustomPressurePlate(Sensitivity p_i48348_1_, Properties p_i48348_2_) {
        super(p_i48348_1_, p_i48348_2_);
    }
}
