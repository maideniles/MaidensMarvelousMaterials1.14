package com.maideniles.maidensmaterials.block;

import net.minecraft.block.BlockState;
import net.minecraft.block.StairsBlock;

public class CustomStairs extends StairsBlock {
    public CustomStairs(BlockState state, Properties properties) {
        // >:(
        super(state, properties);
    }
}