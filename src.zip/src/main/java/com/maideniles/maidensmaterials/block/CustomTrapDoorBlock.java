package com.maideniles.maidensmaterials.block;

import net.minecraft.block.DoorBlock;
import net.minecraft.block.TrapDoorBlock;

public class CustomTrapDoorBlock extends TrapDoorBlock {
    public CustomTrapDoorBlock(Properties builder) {
        super(builder);
    }
}
