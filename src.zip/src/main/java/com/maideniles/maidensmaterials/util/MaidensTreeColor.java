package com.maideniles.maidensmaterials.util;

public enum MaidensTreeColor {
    RED, //CRABAPPLE
    ORANGE, // POINCIANA
    YELLOW, //LABURNUM
    GREEN,  //JADE
    TEAL,  //PAULOWNIA
    BLUE,  //WISTERIA
    PURPLE,  //JACARANDA
    PINK,  //DOGWOOD
    WHITE,  //SILVERBELL
    CEDAR,  //CEDAR
    APPLE, //APPLE
    GRAPEFRUIT, //GRAPEFRUIT
    PALM, //PALM

}