package com.maideniles.maidensmaterials.util;

import javax.annotation.Nonnull;

public class ModUtil {

    @SuppressWarnings("ConstantConditions")
    public static @Nonnull
    <T> T getNull() {
        return null;
    }
}
